package application;

import java.util.ArrayList;
import java.util.HashMap;

public class GA {
	
	int zone=0,count=1; 
	static ArrayList<ArrayList<Integer>> modsinzone;
	static HashMap<Integer,MyObject> mapmodnames;
	static int Install_PopSize;
	static int Install_gen = 1;
	static int max_Install_gen ;
	static double Install_CR;
	static double Install_MR ;
	
	static int Hookup_PopSize; 
	static int max_Hookup_gen;
	static double Hookup_CR;
	static double Hookup_MR; 
	static int Hookup_MCrew;
	static int connections;
	static int Hookup_gen;
	static HashMap<Integer,ArrayList<Integer>> connectionMap;
	static HashMap<Integer, Integer> mapmodnums; 
	
	GA(){
		
		zone=0;
		count=1; 
		modsinzone = new ArrayList<ArrayList<Integer>>();
		mapmodnames = new HashMap<Integer,MyObject>();
		Install_gen = 1;
		/*Install_PopSize = Integer.parseInt(Main.Install_PopSize.getText());

		max_Install_gen = Integer.parseInt(Main.Install_gen.getText());
		Install_CR = Double.parseDouble(Main.Install_CR.getText());
		Install_MR = Double.parseDouble(Main.Install_MR.getText());
		
		Hookup_PopSize = Integer.parseInt(Main.Hookup_PopSize.getText());
		max_Hookup_gen = Integer.parseInt(Main.Hookup_gen.getText());
		Hookup_CR = Double.parseDouble(Main.Hookup_CR.getText());
		Hookup_MR = Double.parseDouble(Main.Hookup_MR.getText());
	    Hookup_MCrew = Integer.parseInt(Main.Hookup_MCrew.getText());
	    */
		if(Main.module.size()<110){

			Install_PopSize = 50;
			max_Install_gen = 7;
			Install_CR = 0.9;
			Install_MR = 0.1;
			Hookup_PopSize =50;
			max_Hookup_gen = 10;
			Hookup_CR=0.9;
			Hookup_MR = 0.1;
			Hookup_MCrew = 3;
		}
		else {
			Install_PopSize = 70;
			max_Install_gen = 8;
			Install_CR = 0.9;
			Install_MR = 0.1;
			Hookup_PopSize =70;
			max_Hookup_gen = 12;
			Hookup_CR=0.9;
			Hookup_MR = 0.1;
			Hookup_MCrew = 3;
		}
	    connections = Main.connection.size();

	    Hookup_gen=1;
	    connectionMap = new HashMap<Integer,ArrayList<Integer>>();
	    mapmodnums = new HashMap<Integer,Integer>();
		
		while(count<=Main.module.size()){
			
			zone++;
			
			ArrayList<Integer> mods = new ArrayList<Integer>();
			
			for(int m=0;m<Main.module.size();m++){
				
				
				if(Integer.parseInt(Main.module_label.get(Integer.parseInt(Main.module.get(m).getId())).zone) == zone){
					
					mods.add(count);
					mapmodnames.put(count,Main.module_label.get(Integer.parseInt(Main.module.get(m).getId())));
					mapmodnums.put((int)(Double.parseDouble(Main.module_label.get(Integer.parseInt(Main.module.get(m).getId())).name)),count);
					count++;
							
				}
				
			}
			
			
			modsinzone.add(mods);
		}
		System.out.println(mapmodnums);
		
		for(int conn =1;conn<=Main.connection.size();conn++){
			
			ArrayList<Integer> modules = new ArrayList<Integer>();
			String splited[] = Main.connection.get(conn+"").conn_between.split("[,\\s]+");
			modules.add((int)(Double.parseDouble(splited[0])));
			modules.add((int)(Double.parseDouble(splited[1])));
			connectionMap.put(conn,modules);
		}
		//System.out.println(connectionMap);
		
		
		
	}
}
