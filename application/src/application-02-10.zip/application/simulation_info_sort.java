package application;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class simulation_info_sort {

    public static void sort() {
        final String FILE_NAME = "simulate_info.xlsx";

        //create a workbook from your file
        FileInputStream excelFile = null;
        try {
            excelFile = new FileInputStream(new File(FILE_NAME));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Workbook originalWorkbook = null;
        try {
            originalWorkbook = new XSSFWorkbook(excelFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Sheet originalSheet = originalWorkbook.getSheetAt(0);

        // Create a SortedMap<String, Row> where the key is the value of the first column
        // This will automatically sort the rows
        Map<String, Row> sortedRowsMap = new TreeMap<>();
        Iterator<Row> rowIterator = originalSheet.rowIterator();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            sortedRowsMap.put(row.getCell(2).getStringCellValue(), row);
        }

        // Create a new workbook
        Workbook sortedWorkbook = new XSSFWorkbook();
        Sheet sortedSheet = sortedWorkbook.createSheet(originalSheet.getSheetName());
        FormulaEvaluator evaluator = sortedWorkbook.getCreationHelper().createFormulaEvaluator();


        // Copy all the sorted rows to the new workbook
        int rowIndex = 0;
        for (Row row : sortedRowsMap.values()) {
            Row newRow = sortedSheet.createRow(rowIndex);
            copyRowToRow(row, newRow, evaluator);
            rowIndex++;
        }

        // Write your new workbook to your file
        try (FileOutputStream out = new FileOutputStream(FILE_NAME)) {
            sortedWorkbook.write(out);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Utility method to copy rows
    private static void copyRowToRow(Row row, Row newRow, FormulaEvaluator evaluator) {
        Iterator<Cell> cellIterator = row.cellIterator();
        int cellIndex = 0;
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            Cell newCell = newRow.createCell(cellIndex);
            newCell.setCellValue(cell.getStringCellValue());

            cellIndex++;
        }
    }
}

