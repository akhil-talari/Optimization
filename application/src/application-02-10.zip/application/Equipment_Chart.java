package application;

import static application.GA.mapmodnames;
import static application.Install.*;
import static application.Install.modinstallmonth;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Equipment_Chart{

    public void run(int name, int Hookupname, int duration ){
        GridPane root = new GridPane();
        root.setHgap(10);
        root.setVgap(10);
        root.setPadding(new Insets(0, 10, 0, 10));
        //root.setPrefWrapLength(170); // preferred width allows for two columns
        /*root.setPadding(new Insets(10));
        root.setAlignment(Pos.BASELINE_RIGHT);*/
        //root.getChildren().addAll(createBarChart(name), createLineChart(), createStaggingChart(name));

        root.add(createBarChart(name), 0,0);
        root.add(createLineChart(), 0,1);
        root.add(createStaggingChart(name), 1,0);
         Node n = Area_Chart.run(name);
        root.add(n, 1,1);
        root.add(Hookupchar_bargraph(name, Hookupname, duration), 2,0);

        root.add(Hookupchart_line(name, Hookupname, duration), 2,1);

    	Stage stage = new Stage();
        stage.setScene(
                new Scene(root,500,500));
        stage.show();
    }

    private NumberAxis createYaxis() {
        final NumberAxis axis = new NumberAxis(0, 500, 50);
        //axis.setPrefWidth(35);
        axis.setMinorTickCount(10);

       axis.setLabel("SPMT (axel)");

        return axis;
    }

    private CategoryAxis createXaxis() {
        final CategoryAxis axis = new CategoryAxis();
        axis.setLabel("Project Month");
        axis.setTickLabelGap(10);

        return axis;
    }

    private BarChart<String, Number> createBarChart(int name) {

    //    final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis(0,3,1);
        final BarChart<String, Number> bc =
                new BarChart<String, Number>(createXaxis(), yAxis);
        setDefaultChartProperties(bc);
        bc.setBarGap(0.5);
        bc.setCategoryGap(3);
        yAxis.setSide(Side.LEFT);
        yAxis.setLabel("Quantity (ea)");
        XYChart.Series series2 = new XYChart.Series();
        XYChart.Series series3 = new XYChart.Series();
        series2.setName("600 ton");
        series3.setName("1350 ton");


        for(int i = 29 ; i < 50 ; i++) {
            try {
                if (CranesPerMonth.get(i).contains("NA")) {
                }
                if (CranesPerMonth.get(i).contains("600.0")) {
                    int occurrences = Collections.frequency(CranesPerMonth.get(i), "600.0");
                    series2.getData().add(new XYChart.Data(i + "", 1));
                }else{
                	series2.getData().add(new XYChart.Data(i + "", 0));
                }
                if (CranesPerMonth.get(i).contains("1350.0")) {
                    int occurrences = Collections.frequency(CranesPerMonth.get(i), "1350.0");
                    series3.getData().add(new XYChart.Data(i + "", 1));
                }else{
                	series3.getData().add(new XYChart.Data(i + "", 0));
                }
            }
            catch (NullPointerException ex){
            	series2.getData().add(new XYChart.Data(i + "", 0));
            	series3.getData().add(new XYChart.Data(i + "", 0));
            	
            }
        }
        bc.setTitle("Equipment Histogram: Setting scenario: "+name);
        bc.setScaleShape(true);

        bc.getData().addAll(series2, series3);
   
       // bc.relocate(100, 400);
        return bc;
    }

    private LineChart<String, Number> createLineChart() {
        final LineChart<String, Number> chart = new LineChart<>(createXaxis(), createYaxis());
        setDefaultChartProperties1(chart);

        chart.setCreateSymbols(false);

      
        XYChart.Series series1 = new XYChart.Series();
        for(int i=0;i<21;i++){
			series1.getData().add(new XYChart.Data(i+29+"", SPMTUsedpermonth.get(i+29)));	
		}
                        		
        chart.getData().addAll(series1);
        series1.setName("SPMT Axels");
      //  chart.setPadding(new Insets(5, 54.5, 5, 0));
        
        return chart;
    }

    private void setDefaultChartProperties(final XYChart<String, Number> chart) {
        chart.setLegendVisible(true);
        chart.setAnimated(false);
    }
    private void setDefaultChartProperties1(final XYChart<String, Number> chart) {
        chart.setLegendVisible(true);
        chart.setAnimated(false);
    }

    private StackPane layerCharts(final XYChart<String, Number>... charts) {
        for (int i = 1; i < charts.length; i++) {
            configureOverlayChart(charts[i]);
        }
        StackPane stackpane = new StackPane();
        stackpane.getChildren().addAll(charts);
        return stackpane;
    }

    private void configureOverlayChart(final XYChart<String, Number> chart) {
        chart.setAlternativeRowFillVisible(false);
        chart.setAlternativeColumnFillVisible(false);
        chart.setHorizontalGridLinesVisible(false);
        chart.setVerticalGridLinesVisible(false);
        chart.getXAxis().setVisible(false);
        chart.getYAxis().setVisible(false);
        chart.getStylesheets().addAll(getClass().getResource("application1.css").toExternalForm());
    }

    public Node createStaggingChart(int name) {

        Stage primaryStage = new Stage();
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final BarChart<String, Number> bc = new BarChart<String, Number>(xAxis, yAxis);
        bc.setCategoryGap(0);
        bc.setBarGap(1);
        xAxis.setLabel("Project Month");
        yAxis.setLabel("Area (square meter)");
        XYChart.Series series2 = new XYChart.Series();


        for(int i = 29 ; i < 60 ; i++) {

            XYChart.Data data = new XYChart.Data(i + "", StagingAreaPerMonth.get(i));
            series2.getData().add(data);
            data.nodeProperty().addListener(new ChangeListener<Node>() {
                @Override
                public void changed(ObservableValue<? extends Node> ov, Node oldNode, Node newNode) {
                    newNode.setStyle("-fx-bar-fill: red;");


                }
            });

        }
        bc.getData().addAll(series2);
        bc.setTitle("Stagging Area Chart: Setting scenario: "+name);
        bc.setLegendVisible(false);

        bc.getStylesheets().addAll(getClass().getResource("application.css").toExternalForm());

        //primaryStage.setScene(new Scene(bc,800,450));
        //primaryStage.show();

        return bc;
    }

    public Node Hookupchar_bargraph(int name, int Hookupname, int duration) {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final BarChart<String,Number> barChart = new BarChart<>(xAxis,yAxis);
        barChart.setCategoryGap(0);
        barChart.setBarGap(1);
        barChart.setTitle("Manpower Histogram: Hookup Scenario: "+Hookupname);
        xAxis.setLabel("Project Month");
        yAxis.setLabel("Crew Used");

        XYChart.Series series1 = new XYChart.Series();
        for(int i=29;i<=duration;i++){
            XYChart.Data data = new XYChart.Data(i+"",Hookup.crewUsedpermonth.get(i));
            series1.getData().add(data);
            data.nodeProperty().addListener(new ChangeListener<Node>() {
                @Override
                public void changed(ObservableValue<? extends Node> ov, Node oldNode, Node newNode) {
                    newNode.setStyle("-fx-bar-fill: red;");
                }
            });
        }
        barChart.getData().addAll(series1);
        barChart.setLegendVisible(false);
        barChart.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        return barChart;
    }

    public Node Hookupchart_line(int name, int Hookupname, int duration) {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Crew Used");

        final LineChart<String, Number> chart = new LineChart<>(createXaxis(), createYaxis());
        setDefaultChartProperties1(chart);

        chart.setCreateSymbols(false);

        XYChart.Series series2 = new XYChart.Series();
        int cumulative = 0;
        for(int i=29;i<=duration;i++){
            cumulative += Hookup.crewUsedpermonth.get(i);
            series2.getData().add(new XYChart.Data(i+"", cumulative));
        }

        chart.getData().addAll(series2);
        series2.setName("Cumulative crew");
        //  chart.setPadding(new Insets(5, 54.5, 5, 0));
        return chart;
    }
}
