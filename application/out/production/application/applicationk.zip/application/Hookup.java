package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Hookup {
	
	static ArrayList<Integer> current;
	static HashMap<Integer,Integer > connStartmonth;
    static HashMap<Integer,Integer > connduration;
    static HashMap<Integer, Integer> crewUsedpermonth;
    static HashMap<String, ArrayList<Integer>> Hchromofobjs;
    static ArrayList<int[]> objsfor2D;
    
	public static void initial() {	
		
		ArrayList<Hookup_Chromosome> current_population = new ArrayList<Hookup_Chromosome>();
		current_population = createChromosomes(GA.Hookup_PopSize);
		Hchromofobjs = new HashMap<String, ArrayList<Integer>>();
		 Scatter2DChart sc = new Scatter2DChart();
		 sc.start();
		 sc.run(0,objsfor2D);
		while(GA.Hookup_gen <= GA.max_Hookup_gen){

			ArrayList<Hookup_Chromosome> offspring_population = new ArrayList<Hookup_Chromosome>();
			offspring_population=GALoop(current_population);

			ArrayList<Hookup_Chromosome> union = new ArrayList<Hookup_Chromosome>();
			union.addAll(current_population);
			union.addAll(offspring_population);

			ArrayList<Hookup_Chromosome> new_population = new ArrayList<Hookup_Chromosome>();
			new_population = newPopAfterRanking(GA.Hookup_PopSize,union);
			sc.run(GA.Hookup_gen,objsfor2D);
			current_population = new_population;

			GA.Hookup_gen = GA.Hookup_gen+1;
		}
	/*	HRanking ranking = new HRanking(current_population);
		ranking.getSubfront(0);*/
	}

	private static ArrayList<Hookup_Chromosome> newPopAfterRanking(int hookup_PopSize, ArrayList<Hookup_Chromosome> union) {
		
		objsfor2D = new ArrayList<int[]>();
		ArrayList<Hookup_Chromosome> new_population = new ArrayList<Hookup_Chromosome>();

		HRanking ranking = new HRanking(union);

		int remain = hookup_PopSize;
		int index = 0;
		ArrayList<Hookup_Chromosome> front = null;

		// Obtain the next front
		front = ranking.getSubfront(index);

		while ((remain > 0) && (remain >= front.size())) {

			//Add the individuals of this front
			for (int k = 0; k < front.size(); k++) {
				new_population.add(front.get(k));
				int[] point = new int[2];
				point[0] = front.get(k).objectives[0];
				point[1] = front.get(k).objectives[1];
				objsfor2D.add(point);
				Hchromofobjs.put(point[0]+" "+point[1],front.get(k).sequence);
			} 

			remain = remain - front.size();

			index++;
			if (remain > 0) {
				front = ranking.getSubfront(index);
			}       
		} 

		if (remain > 0) {                       

			for (int k = 0; k < remain; k++) {
				new_population.add(front.get(k));
				int[] point = new int[2];
				point[0] = front.get(k).objectives[0];
				point[1] = front.get(k).objectives[1];
				objsfor2D.add(point);
				Hchromofobjs.put(point[0]+" "+point[1],front.get(k).sequence);
			} 

			remain = 0;
		}
		return new_population; 
	}

	private static ArrayList<Hookup_Chromosome> GALoop(ArrayList<Hookup_Chromosome> current_population) {
		
		Random r=new Random(System.currentTimeMillis());

		ArrayList<Hookup_Chromosome> offspring_population = new ArrayList<Hookup_Chromosome>();

		for(int i=0;i<current_population.size();i++){

			offspring_population.add(null);
		}
		for(int i=0;i<offspring_population.size();i++){

			offspring_population.set(i,evolvePopulation(current_population,r));		
		}
		return offspring_population;
	}

	private static Hookup_Chromosome evolvePopulation(ArrayList<Hookup_Chromosome> current_population, Random r) {
		
		int tournamentSize = 2;
		double crossoverRate = GA.Hookup_CR;
		double mutationRate = GA.Hookup_MR;
		
		ArrayList<Integer> tour1 = new ArrayList<Integer>();
		ArrayList<Integer> tour2 = new ArrayList<Integer>();
		
		tour1 = tournamentSelection(current_population,tournamentSize,r);
		tour2 = tournamentSelection(current_population,tournamentSize,r);
		
		ArrayList<Integer> offspring = new ArrayList<Integer>();
	
		offspring = crossOver(crossoverRate,tour1,tour2,r);
		offspring = mutate(offspring,mutationRate,r);
		
		Hookup_Chromosome new_offspring = new Hookup_Chromosome(offspring);
		evaluate_objs(new_offspring);
		
		return new_offspring;
	}

	private static ArrayList<Integer> mutate(ArrayList<Integer> offspring,double mutationRate, Random r) {
		
		for (int swapPos1 = 0; swapPos1 < offspring.size(); swapPos1++) {
			float f = r.nextFloat();
			if (f < mutationRate) {

				int swapPos2 = r.nextInt(offspring.size());
				int swapCity1 = offspring.get(swapPos1);
				int swapCity2 = offspring.get(swapPos2);
				offspring.set(swapPos1, swapCity2);
				offspring.set(swapPos2, swapCity1);

			}
		}
		return offspring;
	}

	private static ArrayList<Integer> crossOver(double crossoverRate,ArrayList<Integer> tour1, ArrayList<Integer> tour2, Random r) {
		
		ArrayList<Integer> offspring=new ArrayList<Integer>();

		for(int i=0;i<tour1.size();i++){
			offspring.add(null);
		}

		float f = r.nextFloat();
		if (f < crossoverRate) {
			int crossPoint = (int) (Math.random() * tour1.size());//make a crossover point
			for (int i = 0; i < tour1.size(); ++i) {
				if (i < crossPoint)
					offspring.set(i, tour1.get(i));
				else
					offspring.set(i, tour2.get(i));
			}
		} else {
			offspring.clear();
			offspring.addAll(tour1);
		}

		return offspring;
	}

	private static ArrayList<Integer> tournamentSelection(ArrayList<Hookup_Chromosome> current_population,int tournamentSize, Random r) {
		
		Hookup_Chromosome solution1, solution2;
	    solution1 = current_population.get(r.nextInt(current_population.size()));
	    solution2 = current_population.get(r.nextInt(current_population.size()));

	    if (current_population.size() >= 2)
	    	while (solution1 == solution2)
	        solution2 = current_population.get(r.nextInt(current_population.size()));
	    
	    int flag = HRanking.compare(solution1,solution2);
	    if (flag == -1)
	      return solution1.sequence;
	    else if (flag == 1)
	      return solution2.sequence;
	    else
	      if (r.nextDouble()<0.5)
	        return solution1.sequence;
	      else
	        return solution2.sequence;
	}

	private static ArrayList<Hookup_Chromosome> createChromosomes(int hookup_PopSize) {
		
		objsfor2D = new ArrayList<int[]>();
		Random r = new Random();
		
		ArrayList<Hookup_Chromosome> population = new ArrayList<Hookup_Chromosome>();
        
		for (int j = 0; j < GA.Hookup_PopSize; j++) {
            population.add(null);
        }
		for (int i = 0; i < hookup_PopSize; i++) {

			ArrayList<Integer> list = new ArrayList<Integer>();

			for (int j = 0; j < GA.connections; j++) {

				list.add(r.nextInt(GA.Hookup_MCrew)+1);
			}
			Hookup_Chromosome newChrom = new Hookup_Chromosome(list);
			evaluate_objs(newChrom);
			population.set(i, newChrom);
			int[] point = new int[2];
			point[0] = newChrom.objectives[0];
			point[1] = newChrom.objectives[1];
			objsfor2D.add(point);
			/*System.out.println(point[0]+" "+point[1]);
			System.out.println(newChrom.sequence);
			System.out.println("");
			Hchromofobjs.put(point[0]+" "+point[1],newChrom.sequence);*/
		}
		return population;
	}

	private static void evaluate_objs(Hookup_Chromosome thisChrom) {
		
		int obj1 = 0,obj2 = 0;

		obj1 = getTotalMonth(thisChrom.sequence);
		obj2 = getResourceVariation(thisChrom.sequence);
		
		thisChrom.objectives[0] = obj1;
		thisChrom.objectives[1] = obj2;
		
	}

	private static int getResourceVariation(ArrayList<Integer> sequence) {
		
		Unit[] units = Hookup_getSchedule(sequence);
		int totalCrewVariation = 0;
		int previousTotalCrew = 0;
		int totalMonths = 0;

		for (int i = 0; i < 50; i++) {
			Unit unit = units[i];

			int totalCrews = 0;
			for (Integer machine : unit.machines) {
				totalCrews += unit.crewOfMachine.get(machine);
			}

			totalCrewVariation += Math.abs(totalCrews - previousTotalCrew);
			previousTotalCrew = totalCrews;
		}

		totalCrewVariation += previousTotalCrew;
		return totalCrewVariation;
	}

	private static int getTotalMonth(ArrayList<Integer> sequence) {
		
		Unit[] units = Hookup_getSchedule(sequence);

		int totalMonths = 0;

		for (int i = 0; i < 50; i++) {
			Unit unit = units[i];

			int totalCrews = 0;
			for (Integer machine : unit.machines) {
				totalCrews += unit.crewOfMachine.get(machine);
			}
			if (totalCrews > 0) {
				totalMonths = i+29 ;
			}
		}
		return totalMonths;

	}
	public static Unit[] Hookup_getSchedule(ArrayList solution) {

		Unit[] u  = Install.getFullSchedule(current);
		
		connStartmonth = new HashMap<Integer, Integer>();
		crewUsedpermonth = new HashMap<Integer, Integer>();
		connduration = new HashMap<Integer,Integer>();

		Unit[] units = new Unit[50];

		for (int i = 0; i < 50; i++) {
			units[i] = new Unit();
			crewUsedpermonth.put(i+29, 0);
		}
		boolean[] connectionUsed = new boolean[GA.connections];
		// Loop through all the months
		for (int i = 0; i < 50 - 1; i++) {

			Unit unit = units[i];

			boolean allMachineAllocated = true;
			int totalCrew = getCrewLimitForTheMonth(i+29);


			// Sanity check
			for (int k = 0; k < GA.connections; k++) {

				if (connectionUsed[k] == false) {
					allMachineAllocated = false;
				}
			}
			if (allMachineAllocated) break;

			int count = 0;

			while (true) {

				count++;
				if (unit.crewUsed >= totalCrew) break;
				// Get the next available connection
				//System.out.println("Month"+i);
				Integer connectionToAllocate = giveNextAvailableConnection(i+29, connectionUsed);


				int g = connectionToAllocate + 1;

				if (connectionToAllocate == -1) break;

				if (count > 50) {
					break;
				}

				if (!connectionUsed[connectionToAllocate]) {
					// Get number of crews for connection from chromosome
					int crew = getCrewForConnection(solution, connectionToAllocate);
					int duration = getDuration(connectionToAllocate + 1, crew);

					try {
						// ********** Important ***********
						// Check if future months exceed crew limit
						// IF this connection even in future exceeds total crew limit, then skip
						//*********************************
						//
						boolean noMonthsExceedsCrewLimit = true;
						for (int j = i; j < i + duration; j++) {

							if (units[j].crewUsed + crew > getCrewLimitForTheMonth(j+29)) {//check if for the following months is it okay to add crews for the current connection

								noMonthsExceedsCrewLimit = false;
								break;
							}
						}
						if (noMonthsExceedsCrewLimit == false) break;

						if (noMonthsExceedsCrewLimit) {

							connectionUsed[connectionToAllocate] = true; //now good to hookup this m/c
							int conn_duration =0;
							for (int j = i; j < i + duration; j++) {

								if (units[j].crewUsed + crew > totalCrew) {

									System.out.println("WTH!!!!!!");
								}
								units[j].machines.add(connectionToAllocate+1);
								units[j].crewOfMachine.put(connectionToAllocate+1, crew);
								units[j].crewUsed += crew;
								crewUsedpermonth.put(j+29, units[j].crewUsed);
								if(!connStartmonth.containsKey(connectionToAllocate+1)){
									connStartmonth.put(connectionToAllocate+1, j+29);
								}
								connduration.put(connectionToAllocate+1, ++conn_duration);
							}
						}
					} catch (Exception ex) {
						//break;
						System.out.println("HERE: " + duration);
					}
				}

				allMachineAllocated = true;
				for (int k = 0; k < GA.connections; k++) {
					if (connectionUsed[k] == false) {
						allMachineAllocated = false; //just to check if every m/c is used or not
					}
				}

				if (allMachineAllocated) break;
			}

		}
		//System.out.println("Getting out!");
		return units;

	}

	public static int getCrewForConnection(ArrayList solution, Integer connectionToAllocate) {

		for (int i = 0; i < solution.size(); i++) {
			if (connectionToAllocate == i)
				return (int) solution.get(i);
		}
		return -1;
	}
	private static int getCrewLimitForTheMonth(int i) {
		return 20;
	}
	private static Integer giveNextAvailableConnection(int month, boolean[] connectionUsed) {

		List<Integer> availMacs = getMachinesforMonth(month);
		for (int k = 0; k < availMacs.size(); k++) {
			if (connectionUsed[availMacs.get(k) - 1] == false) return availMacs.get(k) - 1;
		}
		return -1;
	}
	private static List<Integer> getMachinesforMonth(int month) {

		ArrayList<ArrayList<Integer>> connections = new ArrayList<ArrayList<Integer>>();
		if (connections.size() == 0) {

			for (int ind = 0; ind <55; ind++) {
				connections.add(new ArrayList<>());
			}
		}
		for (int j = 1; j <= GA.connections; j++) {

			if (getMonthForConnection(j) <= month) {

				connections.get(month-29).add(j);
			}
		}
		//System.out.println(connections.get(month));
		return connections.get(month-29);
	}
	private static int getMonthForConnection(int conn) {
		int month =0;
		ArrayList<Integer> conn_modules = new ArrayList<Integer>();
		conn_modules = GA.connectionMap.get(conn);
		int module1 = GA.mapmodnums.get(conn_modules.get(0));
		int module2 = GA.mapmodnums.get(conn_modules.get(1));
		//System.out.println(module1+" "+module2);

		//System.out.println(conn+"->"+Math.max(getmodInstallMonth(conn_modules.get(0)), getmodInstallMonth(conn_modules.get(1))));
		try{
			month =  Math.max(Install.modinstallmonth.get(module1),Install.modinstallmonth.get(module2));
		}
		catch(NullPointerException e){
			System.out.println(module1+" "+module2);
			System.out.println(Install.modinstallmonth);
			System.out.println(Install.modinstallmonth.get(module1));
			System.out.println(Install.modinstallmonth.get(module2));

			System.exit(0);
		}
		return month;
	}

	private static double getCrewIntoDuration(int id) {

		if (id == 1 || id == 2) return 67;
		if (id == 3) return 20.325;
		if (id == 4) return 142.5;
		if (id == 5 || id == 6 || id == 7) return 202.5;
		if (id == 8 || id == 9 || id == 10) return 142.5;
		if (id == 11 || id == 12) return 135;
		if (id == 13 || id == 14 || id == 15 || id == 16) return 108.75;
		if (id == 17) return 7.5;
		if (id == 18) return 28.5;
		if (id == 19 || id == 20 || id == 21) return 49.5;
		if (id == 22) return 40.5;
		if (id == 23 || id == 24) return 142.5;
		if (id == 25 || id == 26) return 108.75;
		if (id == 27) return 202.5;
		if (id == 28) return 168.75;
		if (id == 29 || id == 30 || id == 31) return 135;
		if (id == 32 || id == 33 || id == 34 || id == 35) return 108.75;
		if (id == 36 || id == 37 || id == 38) return 49.5;
		if (id == 39) return 40.5;
		if (id == 40 || id == 41 || id == 42 || id == 43 || id == 44 || id ==45) return 15.75;
		if (id == 46) return 7.875;
		if (id == 47) return 2.925;
		if (id == 48) return 7.325;
		if (id == 49) return 4.395;
		if (id == 50) return 5.85;
		if (id == 51) return 7.325;
		if (id == 52) return 4.395;
		if (id == 53 || id == 54 || id == 55) return 5.85;
		if (id == 56 || id == 57) return 4.395;
		if (id == 58 || id == 59 || id == 60) return 5.85;
		if (id == 61) return 7.325;
		if (id == 62) return 4.395;
		if (id == 63 || id == 64 || id == 65) return 5.85;
		if (id == 66) return 7.325;
		if (id == 67 || id == 68) return 4.395;
		if (id == 69 || id == 70) return 5.85;
		if (id == 71) return 7.325;
		if (id == 72) return 4.395;
		if (id == 73 || id == 74 || id == 75) return 5.85;
		if (id == 76) return 7.325;
		if (id == 77) return 4.395;
		if (id == 78) return 40;
		if (id == 79 || id == 80 || id == 81 || id == 82) return 7.325;
		if (id == 83) return 9.75;
		if (id == 84 || id == 85 || id == 86 || id == 87|| id == 88|| id == 89|| id == 90 || id == 91 || id == 92) return 7.325;
		if (id == 93) return 2.45;
		if (id == 94 || id == 95 || id == 96 || id == 97) return 15.75;
		if (id == 98 || id == 99) return 11.25;
		if (id == 100 || id == 101 || id == 102 || id == 103 || id == 104) return 6.75;
		if (id == 105) return 27.2;
		if (id == 106) return 28.15;
		if (id == 107) return 27.2;
		if (id == 108) return 28.15;
		if (id == 109) return 27.2;
		if (id == 110) return 47.825;
		if (id == 111) return 46.825;
		if (id == 112) return 39.375;
		if (id == 113) return 39.375;

		throw new RuntimeException("Connection Invalid!" + id);
	}

	// connectionId starts from 1
	public static int getDuration(int connectonId, int crew) {

		int months = (int)Math.ceil(getCrewIntoDuration(connectonId) / (25*crew));
		return months;
	}



}
