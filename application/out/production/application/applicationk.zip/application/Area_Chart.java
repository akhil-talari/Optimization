package application;

import javafx.scene.Node;

import static application.Install.modinstallmonth;
import static application.GA.mapmodnames;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class Area_Chart {

	public static ArrayList<areaStartend> list;
	public static Node run(int name){
		
		Set<String> area = Main.areas.keySet();
		 list = new ArrayList<areaStartend>();
		
		for( String s: area){
			
			areaStartend a = new areaStartend(s);
			
			for(int i=1; i<=mapmodnames.size();i++){
				
				if(mapmodnames.get(i).area.equals(s)){
					
					if(modinstallmonth.get(i)<a.start){
						a.start = modinstallmonth.get(i);
					}
					else if(modinstallmonth.get(i)>a.end){
						a.end = modinstallmonth.get(i);
					}
					
				}
			}
			list.add(a);
			
		}
		
		 return GanttChart.start_GanttChart(name);
		
	}
	
	
}
 class areaStartend{
	
	int start;
	int end;
	String Area = null;
	
	areaStartend(String area){
		
		Area = area;
		start=100;
		end =0;
	}
	
}
