package application;



public class MyObject {

	public String name;
	int color=0;
	String text="";
	public String id;
	public String area;
	public String cat;
	public String des;
	public String width;
	public String length;
	public String height;
	public String ton;
	public String weight_mt;
	public String land;
	public String axe;
	public String lift;
	public String crane;
	public String ROS;
	public String set_date;
	public String remarks;
	public String x;
	public String y;
	public String objheight;
	public String objwidth;
	public String zone;
	
	MyObject(String name){
		this.name = name;
	}
}
