package application;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.*;
import java.util.HashMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import static application.Hookup.connStartmonth;

public class simulation_conn_info {

    HashMap<String, MyConn> conn_label;
    File file1;

    public simulation_conn_info(HashMap<String, MyConn> conn_label) {
        this.conn_label = conn_label;
        store_data();
    }

    void store_data() {
        try {
            //FileInputStream myxls = new FileInputStream("simulate_conn_info.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("Information");

            int rowCount = 0;

            for (int i=1;i<=conn_label.size();i++) {
                MyConn temp = conn_label.get(i+"");
                Row row = sheet.createRow(rowCount++);

                int columnCount = 0;
                Cell cell = row.createCell(columnCount++);
                cell.setCellValue((String) temp.Name);
                cell = row.createCell(columnCount++);
                cell.setCellValue((String) temp.Conn_Type);
                cell = row.createCell(columnCount++);
                cell.setCellValue(connStartmonth.get(i));
                cell = row.createCell(columnCount++);
                cell.setCellValue((String) temp.conn_between);
                cell = row.createCell(columnCount++);
                cell.setCellValue((Double) temp.startx);
                cell = row.createCell(columnCount++);
                cell.setCellValue((Double) temp.starty);
                cell = row.createCell(columnCount++);
                cell.setCellValue((Double) temp.endx);
                cell = row.createCell(columnCount++);
                cell.setCellValue((Double) temp.endy);
                cell = row.createCell(columnCount++);
                cell.setCellValue((Integer) temp.orientation);

            }
            FileOutputStream outFile = new FileOutputStream(new File(
                    "simulate_conn_info.xlsx"));
            workbook.write(outFile);
            outFile.close();
            workbook.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
