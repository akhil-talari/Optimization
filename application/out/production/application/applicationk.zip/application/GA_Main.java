package application;

import java.io.IOException;

public class GA_Main {

    public static void run() throws IOException, InterruptedException {
        new GA();
        new Install();
    }
}
