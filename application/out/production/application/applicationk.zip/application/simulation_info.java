package application;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;

import java.io.*;
import java.util.HashMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;

import static application.GA.mapmodnums;
import static application.Install.modinstallmonth;
import static application.Main.module;

public class simulation_info {

    HashMap<Integer, MyObject> module_label ;
    File file1;

    public simulation_info(HashMap<Integer, MyObject> module_label) {
        this.module_label = module_label;
        store_data();
    }

    void store_data() {
        try {
            FileInputStream myxls = new FileInputStream("simulate_info.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(myxls);
            XSSFSheet sheet = workbook.getSheet("Information");

            int rowCount = 0;

        for (int i = 0; i < module_label.size(); i++) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
            Cell cell = row.createCell(columnCount++);
            cell.setCellValue(module_label.get(i).name);
            cell = row.createCell(columnCount++);
            cell.setCellValue(module_label.get(i).area);
            double d = Double.parseDouble(module_label.get(i).name);
            cell = row.createCell(columnCount++);
            cell.setCellValue(modinstallmonth.get(mapmodnums.get((int) d)));
            cell = row.createCell(columnCount++);
            cell.setCellValue( module_label.get(i).x);
            cell = row.createCell(columnCount++);
            cell.setCellValue(module_label.get(i).y);
            cell = row.createCell(columnCount++);
            cell.setCellValue(module.get(i).getHeight());
            cell = row.createCell(columnCount++);
            cell.setCellValue(module.get(i).getWidth());

        }

            FileOutputStream outFile = new FileOutputStream(new File(
                    "simulate_info.xlsx"));
            workbook.write(outFile);
            outFile.close();
            workbook.close();

    } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
