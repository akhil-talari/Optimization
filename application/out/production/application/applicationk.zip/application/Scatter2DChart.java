package application;

import java.util.ArrayList;

import com.orsoncharts.data.xyz.XYZItemKey;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import static application.Hookup.connStartmonth;
import static application.Install.getFullSchedule;
import static application.Install.modinstallmonth;
import static application.Main.connection;
import static application.Main.module_label;


public class Scatter2DChart {
	
	 NumberAxis xAxis;
	 NumberAxis yAxis;
	 ScatterChart<Number,Number> sc;
	 
	Scatter2DChart(){
		
		xAxis = new NumberAxis(29, 60, 1);
	    yAxis = new NumberAxis(10, 100,10 );        
	    sc = new ScatterChart<Number,Number>(xAxis,yAxis);
	  //  sc.setTitle(name+"");
	}
	
 
    public void start() {
    	
    	Stage stage = new Stage();
        stage.setTitle("Scatter Chart Hookup");
               
        xAxis.setLabel(" Project Month");                
        yAxis.setLabel("Resource Variation (Crew)");
              
        Scene scene  = new Scene(sc, 500, 400);
        stage.setScene(scene);
        stage.show();
    }
 
    public void run(int name, ArrayList<int[]> objsfor2D) {
    	
    	Thread updateThread = new Thread(() -> {
    	     
      	  
            try {
          
              Thread.sleep(20000);
              Platform.runLater(() -> run1(name, objsfor2D));
            } catch (InterruptedException e) {
              throw new RuntimeException(e);
            }
        	
        });
        
        updateThread.setDaemon(true);
        updateThread.start();
     
    }


	private void run1(int name,ArrayList<int[]> objsfor2D) {

		if (sc.getData() == null) 
            sc.setData(FXCollections.<XYChart.Series<Number,Number>>observableArrayList());
        ScatterChart.Series<Number, Number> series = new ScatterChart.Series<Number, Number>();
        series.setName("generation: "+name);
     	sc.getData().add(series);
        for (int i=0; i<objsfor2D.size(); i++) {
        	
        	int temp[] = new int[2];
	    	temp = objsfor2D.get(i);
	    	
        	ScatterChart.Data<Number, Number> data = new ScatterChart.Data<Number, Number>(temp[0], temp[1]);
        	
        	series.getData().add(data);
        	data.setExtraValue(i);
        	data.getNode().setOnMouseClicked(e -> 
        		{
                    ArrayList<Integer> newTour =  Hookup.current;
                    int area =  Install.getTotalStorage(newTour);

                    ArrayList<Integer> newTour2  = Hookup.Hchromofobjs.get((int)data.getXValue()+" "+(int)data.getYValue());
                    Unit[] units2 = Hookup.Hookup_getSchedule(newTour2);
                    Platform.runLater(new Runnable() {
                        int num1 = (GA.max_Install_gen-1)*GA.Install_PopSize+1;
                        int num = (name-1)*GA.Hookup_PopSize+(int)data.getExtraValue();
                   	    @Override
                   	    public void run() {

                            new Equipment_Chart().run(num1, num, (int)data.getXValue()  );
                            //System.out.println(modinstallmonth);
                            System.out.println(connStartmonth);

                            new simulation_info(module_label);
                            new simulation_conn_info(connection);

      	                    //Histogram.start_Hist("Manpower Histogram  Setting Scenario: "+num1+" Hookup Scenario: "+num,(int)data.getXValue());
                   	    }
                   	});
        		}
            );
        	
        }
        
       
	}
 }